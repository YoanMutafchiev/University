﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentInfoSystem
{
   public class MainFormVM : INotifyPropertyChanged
    {
        private Student student;

        public event PropertyChangedEventHandler PropertyChanged;

        public string Title
        {
            get { return "Студентска информационна система"; }
        }
        public Student CurrentStudent
        {
            get { return student; }
            set
            {
                if (student != value)
                {
                    student = value;
                    OnPropertyChanged("CurrentStudent");
                }
            }
        }
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
