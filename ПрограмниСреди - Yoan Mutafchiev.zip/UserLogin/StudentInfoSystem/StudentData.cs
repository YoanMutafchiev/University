﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserLogin;
namespace StudentInfoSystem
{
   class StudentData
    {
        private static List<Student> _testUsers;

        public static List<Student> TestStudents
        {
            get
            {
                ResetTestStudents();
                return _testUsers;
            }
            private set { }
        }

        private static void ResetTestStudents()
        {
            if (_testUsers == null)
            {
                _testUsers = new List<Student>();
                _testUsers.Add(new Student("Petur", "Kirilov", "Petrov", "FKST", "KSI", "bachelor", "interrupted", "121217089", 3, 9, 37));

            }
        }
    }
}
