﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UserLogin;

namespace StudentInfoSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        User tempuser;

        public MainWindow(User u1)
        {
            InitializeComponent();
            this.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            tempuser = u1;
            string roleTemp = Convert.ToString(u1.Role);
            
            if (roleTemp.Equals("STUDENT"))
            {
                fillData(StudentValidation.GetStudentDataByUser(u1));
            } 

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            nameField.Text = "";
            secondNameField.Text = "";
            thirdNameField.Text = "";
            facultyField.Text = "";
            specField.Text = "";
            oksField.Text = "";
            statusField.Text = "";
            facNumberField.Text = "";
            courseField.Text = "";
            flowField.Text = "";
            groupField.Text = "";

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            nameField.IsEnabled = true;
            secondNameField.IsEnabled = true;
            thirdNameField.IsEnabled = true;
            facultyField.IsEnabled = true;
            specField.IsEnabled = true;
            oksField.IsEnabled = true;
            statusField.IsEnabled = true;
            facNumberField.IsEnabled = true;
            courseField.IsEnabled = true;
            flowField.IsEnabled = true;
            groupField.IsEnabled = true;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            nameField.IsEnabled = false;
            secondNameField.IsEnabled = false;
            thirdNameField.IsEnabled = false;
            facultyField.IsEnabled = false;
            specField.IsEnabled = false;
            oksField.IsEnabled = false;
            statusField.IsEnabled = false;
            facNumberField.IsEnabled = false;
            courseField.IsEnabled = false;
            flowField.IsEnabled = false;
            groupField.IsEnabled = false;
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            User user = new User();
            string username = Login.userField;
            //MessageBox.Show(username);
            foreach (User u in UserData.TestUsers)
            {
                if (username.Equals(u.Username))
                {
                    user.Username = username;
                    user.FacNumber = u.FacNumber;
                    user.Password = u.Password;
                    user.Role = u.Role;
                }

            }
            string role = Convert.ToString(user.Role);
           
            if (role.Equals("STUDENT"))
            {
                fillData(StudentValidation.GetStudentDataByUser(user));
            }
            else
            {
                MessageBox.Show("Вие не сте студент! Вашата роля е: " + role);
            }
        }

        private void fillData(Student student)
        {
           /* nameField.Text = student.firstName;
            secondNameField.Text = student.secondName;
            thirdNameField.Text = student.lastName;
            facultyField.Text = student.faculty;
            specField.Text = student.specialty;
            oksField.Text = student.educationqd;
            statusField.Text = student.status;
            facNumberField.Text = student.facultyNumber;
            courseField.Text = Convert.ToString(student.course);
            flowField.Text = Convert.ToString(student.flow);
            groupField.Text = Convert.ToString(student.group); */

            MainFormVM mainFormVM = new MainFormVM();
            mainFormVM.CurrentStudent = student;
            this.DataContext = mainFormVM;

        }
    }
}
