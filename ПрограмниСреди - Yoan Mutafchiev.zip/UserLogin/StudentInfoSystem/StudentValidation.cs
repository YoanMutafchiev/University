﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using UserLogin;

namespace StudentInfoSystem
{
    class StudentValidation
    {
        public static Student GetStudentDataByUser(User user)
        {
            for (int i = 0; i < StudentData.TestStudents.Count; i++)
            {
                if (StudentData.TestStudents[i].facultyNumber == user.FacNumber)
                {
                    return StudentData.TestStudents[i];
                } else
                {
                    MessageBox.Show("Не съвпадат факултетните номера!");
                }
            }
            
            return null;

        }
    }
}
