﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserLogin
{
    class Program
    {
        static void DisplayError(string errorMessage)
        {
            Console.WriteLine("!!! " + errorMessage + " !!!");
        }

        static void showAdminMenu()
        {
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("Изберете опция:");
                Console.WriteLine("0: Изход");
                Console.WriteLine("1: Промяна на роля на потребител");
                Console.WriteLine("2: Промяна на активност на потребител");
                Console.WriteLine("3: Списък на потребителите");
                Console.WriteLine("4: Преглед на лог на активност");
                Console.WriteLine("5: Преглед на текуща активност");

                int option;

                if (!int.TryParse(Console.ReadLine(), out option) || option < 0 || option > 5)
                {
                    Console.WriteLine("Моля изберете отново!");
                    continue;
                }

                switch (option)
                {
                    case 0:
                        Console.WriteLine("Изход");
                        return;
                    case 1:
                        ChangeUserRole();
                        break;
                    case 2:
                        ChangeUserActiveTo();
                        break;
                    case 3:
                        foreach (var user in UserData.TestUsers)
                            Console.WriteLine(user.ToString());
                        break;
                    case 4:
                        StreamReader reader = new StreamReader("test.txt");
                        Console.WriteLine(reader.ReadToEnd());
                        reader.Close();
                        break;
                    case 5:
                        Console.WriteLine(Logger.GetCurrentSessionActivities());
                        break;
                }
            }
        }

        static void ChangeUserRole()
        {
            Console.Write("Въведете име на потребител: ");
            string username = Console.ReadLine();
            Console.WriteLine("Роли: 0-ANONYMOUS, 1-ADMIN, 2-INSPECTOR, 3-PROFESSOR, 4-STUDENT");
            Console.Write("Въведете новата роля: ");
            int role;
            while (true)
            {
                if (!int.TryParse(Console.ReadLine(), out role) || role < 0 || role > 4)
                {
                    Console.WriteLine("Моля изберете отново!");
                    continue;
                }
                else
                    break;
            }
            UserData.AssignUserRole(username, (UserRoles)role);
        }

        static void ChangeUserActiveTo()
        {
            Console.Write("Въведете име на потребител: ");
            string username = Console.ReadLine();
            Console.Write("Въведете новата дата: ");
            DateTime activeTo;
            while (true)
            {
                if (!DateTime.TryParse(Console.ReadLine(), out activeTo))
                {
                    Console.WriteLine("Моля изберете отново!");
                    continue;
                }
                else
                    break;
            }
            UserData.SetUserActiveTo(username, activeTo);
        }

        static void Main(string[] args)
        {
            Console.Write("Потребителско име: ");
            string username = Console.ReadLine();
            Console.Write("Парола: ");
            string password = Console.ReadLine();
            LoginValidation validation = new LoginValidation(username, password, DisplayError);
            User user = null;
            if (validation.ValidateUserInput(ref user))
            {
                Console.WriteLine("Потребител:" + user.ToString());
                Console.Write("Роля: ");
                switch (LoginValidation.currentUserRole)
                {
                    case UserRoles.ADMIN:
                        Console.WriteLine("Администратор");
                        showAdminMenu();
                        break;
                    case UserRoles.PROFESSOR:
                        Console.WriteLine("Професор");
                        break;
                    case UserRoles.INSPECTOR:
                        Console.WriteLine("Инспектор");
                        break;
                    case UserRoles.STUDENT:
                        Console.WriteLine("Студент");
                        break;
                    case UserRoles.ANONYMOUS:
                        Console.WriteLine("Анонимен");
                        break;
                   
                }
            }
            Console.ReadLine();
        }
    }
}