﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserLogin
{
    public static class UserData
    {
        private static List<User> _testUsers;

        public static List<User> TestUsers
        {
            get
            {
                ResetTestUserData();
                return _testUsers;
            }
            set { }
        }

        private static void ResetTestUserData()
        {
            if (_testUsers == null)
            {
                _testUsers = new List<User>();
                _testUsers.Add(new User
                {
                    Username = "ADMIN",
                    Password = "123123",
                    FacNumber = "121217111",
                    Role = UserRoles.ADMIN,
                    Created = DateTime.Now,
                    ActiveTo = DateTime.MaxValue
                });
                _testUsers.Add(new User
                {
                    Username = "Pesho",
                    Password = "Pesho123",
                    FacNumber = "121217089",
                    Role = UserRoles.STUDENT,
                    Created = DateTime.Now,
                    ActiveTo = DateTime.MaxValue
                });
                _testUsers.Add(new User
                {
                    Username = "Gosho",
                    Password = "Gosho123",
                    FacNumber = "121217777",
                    Role = UserRoles.STUDENT,
                    Created = DateTime.Now,
                    ActiveTo = DateTime.MaxValue
                });
            }
        }

        public static User IsUserPassCorrect(string username, string password)
        {
            foreach (var user in TestUsers)
                if (user.Username.Equals(username) && user.Password.Equals(password))
                {
                    return user;
                }

                   
            return null;
        }

        public static void SetUserActiveTo(string username, DateTime activeTo)
        {
            foreach (var user in TestUsers)
                if (user.Username.Equals(username))
                {
                    user.ActiveTo = activeTo;
                    Logger.LogActivity("Промяна на активност: " + username);
                    break;
                }
        }

        public static void AssignUserRole(string username, UserRoles role)
        {
            foreach (var user in TestUsers)
                if (user.Username.Equals(username))
                {
                    user.Role = role;
                    Logger.LogActivity("Промяна на роля: " + username);
                    break;
                }
        }
    }
}
