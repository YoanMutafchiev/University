﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace UserLogin
{
    public class LoginValidation
    {
        private string _username;
        private string _password;
        private string _errorMessage;

        public static string currentUserUsername { get; private set; }

        public static UserRoles currentUserRole { get; private set; }

        public delegate void ActionOnError(string errorMessage);

        private ActionOnError _errorFunc;

        public LoginValidation(string username, string password, ActionOnError errorFunc)
        {
            _username = username;
            _password = password;
            _errorFunc = errorFunc;
        }

        public bool ValidateUserInput(ref User user)
        {
            bool emptyUserName;
            emptyUserName = _username.Equals(string.Empty);
            if (emptyUserName == true)
            {
                _errorMessage = "Не е посочено потребителско име";
                _errorFunc(_errorMessage);
                currentUserUsername = _username;
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }
            if (_username.Length < 5)
            {
                _errorMessage = "Потребителското име не може да бъде по-късо от 5 символа";
                _errorFunc(_errorMessage);
                currentUserUsername = _username;
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }
            bool emptyPassword;
            emptyPassword = _password.Equals(string.Empty);
            if (emptyPassword == true)
            {
                _errorMessage = "Не е посочена парола";
                _errorFunc(_errorMessage);
                currentUserUsername = _username;
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }
            if (_password.Length < 5)
            {
                _errorMessage = "Паролата не може да бъде по-къса от 5 символа";
                _errorFunc(_errorMessage);
                currentUserUsername = _username;
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }
            user = UserData.IsUserPassCorrect(_username, _password);
            if (user != null)
            {
                currentUserUsername = user.Username;
                currentUserRole = user.Role;
                Logger.LogActivity("Успешен Login");

                Console.WriteLine("Добре дошъл: " + user.Username);
                Console.WriteLine();

                if (File.Exists("test.txt")){
                    string line;
                    System.IO.StreamReader file =
     new System.IO.StreamReader("test.txt");
                    List<String> strings = new List<string>();
                    while ((line = file.ReadLine()) != null)
                    {
                        
                        string[] splitter = line.Split(';');
 
                        if (splitter[1].Equals(user.Username)){
                           
                            strings.Add(splitter[0]);
                        }

                    }
                    
                    strings.Reverse();
                    String count = strings[1];
                    DateTime strt_date = DateTime.Now;
                    DateTime end_date = Convert.ToDateTime(count);
                    TimeSpan difference = strt_date - end_date;
                    Console.WriteLine("Последно си влязъл преди " + difference.Days + "д." + difference.Hours + "ч." + difference.Minutes + "мин.");
                 
                    file.Close();
                }
               


                return true;
            }
            else
            {
                _errorMessage = "Потребителят не беше открит";
                _errorFunc(_errorMessage);
                currentUserUsername = _username;
                currentUserRole = UserRoles.ANONYMOUS;
                return false;
            }
        }
    }
}