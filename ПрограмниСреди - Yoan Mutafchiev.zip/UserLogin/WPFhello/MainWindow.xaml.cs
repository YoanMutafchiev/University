﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFhello
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            ListBoxItem james = new ListBoxItem();
            james.Content = "James";
            peopleListBox.Items.Add(james);
            ListBoxItem david = new ListBoxItem();
            james.Content = "David";
            peopleListBox.Items.Add(david);
            peopleListBox.SelectedItem = james;
        }

        private void BtnHello_Click(object sender, RoutedEventArgs e)
        {
            string s = null;
            foreach (var item in MainGrid.Children)
            {

                if (item is TextBox)
                {
                    if (((TextBox)item).Text.Length >= 2)
                    {
                        s = s + ((TextBox)item).Text;
                        s = s + '\n';
                    }
                    else
                    {
                        s= "Името трябва да съдържа поне 2 символа.";
                        break;
                    }
                }
            }            
            MessageBox.Show("Здравейте \n" + s);
        }


        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            if(MessageBox.Show("Сигурни ли сте, че искате да затворите прозореца", "Изход", MessageBoxButton.YesNoCancel) == MessageBoxResult.Yes)
            {
                e.Cancel = false;
            }
            else
            {
                e.Cancel = true;

            }
            
        }

        private void BtnClickMe_Click(object sender, RoutedEventArgs e)
        {
            MyMessage anotherWindow = new MyMessage();
            anotherWindow.Show();
            textBlock1.Text = DateTime.Now.ToString();
        }

        private void BtnGreet_Click(object sender, RoutedEventArgs e)
        {
            string greetingMsg;
            greetingMsg = (peopleListBox.SelectedItem as ListBoxItem).Content.ToString();
            MessageBox.Show("Hi " + greetingMsg);
        }
    }
}
